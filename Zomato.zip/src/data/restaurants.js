export const restaurants =[

        {
            "type": "restaurant",
            "info": {
                "resId": 16538494,
                "name": "Mamaji",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/4/16538494/63c1dd2459951500f15fb67127063749_o2_featured_v2.png"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/4/16538494/63c1dd2459951500f15fb67127063749_o2_featured_v2.png"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "3.5",
                    "rating_text": "3.5",
                    "rating_subtitle": "Good",
                    "rating_color": "9ACD32",
                    "votes": "9,556",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "3.0",
                            "reviewCount": "28",
                            "reviewTextSmall": "28 Reviews",
                            "subtext": "28 Dining Reviews",
                            "color": "#1C1C1C",
                            "ratingV2": "3.0",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Reviews",
                            "bgColorV2": {
                                "type": "yellow",
                                "tint": "600"
                            }
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "4.0",
                            "reviewCount": "9,528",
                            "reviewTextSmall": "9,528 Reviews",
                            "subtext": "9,528 Delivery Reviews",
                            "color": "#E23744",
                            "ratingV2": "4.0",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Reviews",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "600"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹150 for two"
                },
                "cfo": {
                    "text": "₹100 for one"
                },
                "locality": {
                    "name": "Matunga East, Mumbai",
                    "address": "153/A, Nandeep Building, LN Road, Opposite Ruia College, Matunga East, Mumbai",
                    "localityUrl": "mumbai/matunga-east-restaurants"
                },
                "timing": {
                    "text": "",
                    "color": ""
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMzA0XCJdfSJd",
                        "url": "https://www.zomato.com/mumbai/restaurants/sandwich/",
                        "name": "Sandwich"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiOTg5XCJdfSJd",
                        "url": "https://www.zomato.com/mumbai/restaurants/panini/",
                        "name": "Panini"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiODJcIl19Il0%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/pizza/",
                        "name": "Pizza"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTAyM1wiXX0iXQ%3D%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/rolls/",
                        "name": "Rolls"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTI4XCJdfSJd",
                        "url": "https://www.zomato.com/mumbai/restaurants/sichuan/",
                        "name": "Sichuan"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹100 for one"
                }
            },
            "order": {
                "deliveryTime": "24 min",
                "isServiceable": true,
                "hasOnlineOrdering": true,
                "actionInfo": {
                    "text": "Order Now",
                    "clickUrl": "/mumbai/mamaji-matunga-east/order"
                }
            },
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/mumbai/mamaji-matunga-east/order",
                "clickActionDeeplink": ""
            },
            "distance": "894 m",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"2193ad87-028b-4d1a-aee9-f3675127982b\",\"location_type\":\"delivery_cell\",\"location_id\":\"4316646509572521984\",\"page_type\":\"delivery\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"16538494\",\"element_type\":\"listing\",\"rank\":1}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [],
            "promoOffer": "",
            "checkBulkOffers": true,
            "bulkOffers": [
                {
                    "text": "20% OFF",
                    "color": {
                        "tint": "500",
                        "type": "blue"
                    }
                }
            ],
            "isDisabled": false,
            "bottomContainers": [
                {
                    "image": {
                        "url": "https://b.zmtcdn.com/data/o2_assets/4bf016f32f05d26242cea342f30d47a31595763089.png"
                    },
                    "text": "3600+ orders placed from here recently"
                },
                {
                    "image": {
                        "url": "https://b.zmtcdn.com/data/o2_assets/0b07ef18234c6fdf9365ad1c274ae0631612687510.png",
                        "aspect_ratio": 2.66666666667
                    },
                    "text": "Follows all Max Safety measures to ensure your food is safe"
                }
            ]
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 46740,
                "name": "Domino's Pizza",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/chains/1/47211/c9996dd70c88230268cb00d20a92b7cf_o2_featured_v2.jpg"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/chains/1/47211/c9996dd70c88230268cb00d20a92b7cf_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "3.1",
                    "rating_text": "3.1",
                    "rating_subtitle": "Average",
                    "rating_color": "CDD614",
                    "votes": "14.1K",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "2.5",
                            "reviewCount": "595",
                            "reviewTextSmall": "595 Reviews",
                            "subtext": "595 Dining Reviews",
                            "color": "#1C1C1C",
                            "ratingV2": "2.5",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Reviews",
                            "bgColorV2": {
                                "type": "orange",
                                "tint": "300"
                            }
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "3.6",
                            "reviewCount": "13.5K",
                            "reviewTextSmall": "13.5K Reviews",
                            "subtext": "13.5K Delivery Reviews",
                            "color": "#E23744",
                            "ratingV2": "3.6",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Reviews",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "600"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹400 for two"
                },
                "cfo": {
                    "text": "₹100 for one"
                },
                "locality": {
                    "name": "Parel, Mumbai",
                    "address": "7 - 10, Rangoli Time Complex, Dr. Babasaheb Ambedkar Road, Parel, Mumbai",
                    "localityUrl": "mumbai/parel-restaurants"
                },
                "timing": {
                    "text": "",
                    "color": ""
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiODJcIl19Il0%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/pizza/",
                        "name": "Pizza"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNDBcIl19Il0%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/fast-food/",
                        "name": "Fast Food"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTAwXCJdfSJd",
                        "url": "https://www.zomato.com/mumbai/restaurants/desserts/",
                        "name": "Desserts"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjcwXCJdfSJd",
                        "url": "https://www.zomato.com/mumbai/restaurants/beverages/",
                        "name": "Beverages"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹100 for one"
                }
            },
            "order": {
                "deliveryTime": "30 min",
                "isServiceable": true,
                "hasOnlineOrdering": true,
                "actionInfo": {
                    "text": "Order Now",
                    "clickUrl": "/mumbai/dominos-pizza-parel/order"
                }
            },
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/mumbai/dominos-pizza-parel/order",
                "clickActionDeeplink": ""
            },
            "distance": "2 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"2193ad87-028b-4d1a-aee9-f3675127982b\",\"location_type\":\"delivery_cell\",\"location_id\":\"4316646509572521984\",\"page_type\":\"delivery\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"46740\",\"element_type\":\"listing\",\"rank\":2}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [],
            "promoOffer": "",
            "checkBulkOffers": true,
            "bulkOffers": [
                {
                    "text": "40% OFF",
                    "color": {
                        "tint": "500",
                        "type": "blue"
                    }
                }
            ],
            "isDisabled": false,
            "bottomContainers": [
                {
                    "image": {
                        "url": "https://b.zmtcdn.com/data/o2_assets/4bf016f32f05d26242cea342f30d47a31595763089.png"
                    },
                    "text": "5825+ orders placed from here recently"
                },
                {
                    "image": {
                        "url": "https://b.zmtcdn.com/data/o2_assets/0b07ef18234c6fdf9365ad1c274ae0631612687510.png",
                        "aspect_ratio": 2.66666666667
                    },
                    "text": "Follows all Max Safety measures to ensure your food is safe"
                }
            ]
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 17974940,
                "name": "Merwans Cake Stop",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/chains/1/38251/8d9386e15b28007eb0d0f450387d9548_o2_featured_v2.jpg"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/chains/1/38251/8d9386e15b28007eb0d0f450387d9548_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "4.4",
                    "rating_text": "4.4",
                    "rating_subtitle": "Very Good",
                    "rating_color": "5BA829",
                    "votes": "2,167",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "",
                            "reviewCount": "0",
                            "reviewTextSmall": "0 Reviews",
                            "subtext": "Does not offer Dining",
                            "color": "",
                            "ratingV2": "-",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Reviews",
                            "bgColorV2": {
                                "type": "grey",
                                "tint": "500"
                            }
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "4.4",
                            "reviewCount": "2,167",
                            "reviewTextSmall": "2,167 Reviews",
                            "subtext": "2,167 Delivery Reviews",
                            "color": "#E23744",
                            "ratingV2": "4.4",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Reviews",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "700"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹350 for two"
                },
                "cfo": {
                    "text": "₹100 for one"
                },
                "locality": {
                    "name": "Dadar West, Mumbai",
                    "address": "13, Samartha Heights, Gokhale Road North, Opposite Steel King, Dadar West, Mumbai",
                    "localityUrl": "mumbai/dadar-west-restaurants"
                },
                "timing": {
                    "text": "",
                    "color": ""
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNVwiXX0iXQ%3D%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/bakery/",
                        "name": "Bakery"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTAwXCJdfSJd",
                        "url": "https://www.zomato.com/mumbai/restaurants/desserts/",
                        "name": "Desserts"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNDBcIl19Il0%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/fast-food/",
                        "name": "Fast Food"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTAyM1wiXX0iXQ%3D%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/rolls/",
                        "name": "Rolls"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiODJcIl19Il0%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/pizza/",
                        "name": "Pizza"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹100 for one"
                }
            },
            "order": {
                "deliveryTime": "19 min",
                "isServiceable": true,
                "hasOnlineOrdering": true,
                "actionInfo": {
                    "text": "Order Now",
                    "clickUrl": "/mumbai/merwans-cake-stop-dadar-west/order"
                }
            },
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/mumbai/merwans-cake-stop-dadar-west/order",
                "clickActionDeeplink": ""
            },
            "distance": "1.9 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"2193ad87-028b-4d1a-aee9-f3675127982b\",\"location_type\":\"delivery_cell\",\"location_id\":\"4316646509572521984\",\"page_type\":\"delivery\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"17974940\",\"element_type\":\"listing\",\"rank\":3}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [],
            "promoOffer": "",
            "checkBulkOffers": true,
            "bulkOffers": [],
            "isDisabled": false,
            "bottomContainers": [
                {
                    "image": {
                        "url": "https://b.zmtcdn.com/data/o2_assets/4bf016f32f05d26242cea342f30d47a31595763089.png"
                    },
                    "text": "3475+ orders placed from here recently"
                }
            ]
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 19607064,
                "name": "Pawar's Pure Veg",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/4/19607064/0f274544365415d0b333987921023850_o2_featured_v2.jpg"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/4/19607064/0f274544365415d0b333987921023850_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "3.7",
                    "rating_text": "3.7",
                    "rating_subtitle": "Good",
                    "rating_color": "9ACD32",
                    "votes": "1,062",
                    "subtext": "REVIEW",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "3.5",
                            "reviewCount": "13",
                            "reviewTextSmall": "13 Reviews",
                            "subtext": "13 Dining Reviews",
                            "color": "#1C1C1C",
                            "ratingV2": "3.5",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Reviews",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "500"
                            }
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "3.9",
                            "reviewCount": "1,049",
                            "reviewTextSmall": "1,049 Reviews",
                            "subtext": "1,049 Delivery Reviews",
                            "color": "#E23744",
                            "ratingV2": "3.9",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Reviews",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "600"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹300 for two"
                },
                "cfo": {
                    "text": "₹100 for one"
                },
                "locality": {
                    "name": "Prabhadevi, Mumbai",
                    "address": "Shop 8, Sai Complex, Sayani Road, Near Motilal Oswal, Prabhadevi, Mumbai",
                    "localityUrl": "mumbai/prabhadevi-restaurants"
                },
                "timing": {
                    "text": "",
                    "color": ""
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjVcIl19Il0%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/chinese/",
                        "name": "Chinese"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/north-indian/",
                        "name": "North Indian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNDBcIl19Il0%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/fast-food/",
                        "name": "Fast Food"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiOTBcIl19Il0%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/street-food/",
                        "name": "Street Food"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiODVcIl19Il0%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/south-indian/",
                        "name": "South Indian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjcwXCJdfSJd",
                        "url": "https://www.zomato.com/mumbai/restaurants/beverages/",
                        "name": "Beverages"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNzFcIl19Il0%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/malwani/",
                        "name": "Malwani"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTI4XCJdfSJd",
                        "url": "https://www.zomato.com/mumbai/restaurants/sichuan/",
                        "name": "Sichuan"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹100 for one"
                }
            },
            "order": {
                "deliveryTime": "35 min",
                "isServiceable": true,
                "hasOnlineOrdering": true,
                "actionInfo": {
                    "text": "Order Now",
                    "clickUrl": "/mumbai/pawars-pure-veg-prabhadevi/order"
                }
            },
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/mumbai/pawars-pure-veg-prabhadevi/order",
                "clickActionDeeplink": ""
            },
            "distance": "2.6 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"2193ad87-028b-4d1a-aee9-f3675127982b\",\"location_type\":\"delivery_cell\",\"location_id\":\"4316646509572521984\",\"page_type\":\"delivery\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"19607064\",\"element_type\":\"listing\",\"rank\":4}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [],
            "promoOffer": "",
            "checkBulkOffers": true,
            "bulkOffers": [],
            "isDisabled": false,
            "bottomContainers": [
                {
                    "image": {
                        "url": "https://b.zmtcdn.com/data/o2_assets/4bf016f32f05d26242cea342f30d47a31595763089.png"
                    },
                    "text": "1100+ orders placed from here recently"
                }
            ]
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 18953699,
                "name": "Kirti Mahal Legacy",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/9/18953699/ff31f48644497a334af3419c6c687524_o2_featured_v2.jpg"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/9/18953699/ff31f48644497a334af3419c6c687524_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "4.1",
                    "rating_text": "4.1",
                    "rating_subtitle": "Very Good",
                    "rating_color": "5BA829",
                    "votes": "23.2K",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "4.0",
                            "reviewCount": "454",
                            "reviewTextSmall": "454 Reviews",
                            "subtext": "454 Dining Reviews",
                            "color": "#1C1C1C",
                            "ratingV2": "4.0",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Reviews",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "600"
                            }
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "4.1",
                            "reviewCount": "22.7K",
                            "reviewTextSmall": "22.7K Reviews",
                            "subtext": "22.7K Delivery Reviews",
                            "color": "#E23744",
                            "ratingV2": "4.1",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Reviews",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "700"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹650 for two"
                },
                "cfo": {
                    "text": "₹100 for one"
                },
                "locality": {
                    "name": "Parel, Mumbai",
                    "address": "Shop 21, 19, 20, F/S Building, BA Road, Mahapalika, Parel, Mumbai",
                    "localityUrl": "mumbai/parel-restaurants"
                },
                "timing": {
                    "text": "",
                    "color": ""
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiODVcIl19Il0%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/south-indian/",
                        "name": "South Indian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNTBcIl19Il0%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/north-indian/",
                        "name": "North Indian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjVcIl19Il0%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/chinese/",
                        "name": "Chinese"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNDBcIl19Il0%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/fast-food/",
                        "name": "Fast Food"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiODJcIl19Il0%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/pizza/",
                        "name": "Pizza"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiOTBcIl19Il0%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/street-food/",
                        "name": "Street Food"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjcwXCJdfSJd",
                        "url": "https://www.zomato.com/mumbai/restaurants/beverages/",
                        "name": "Beverages"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTA2NlwiXX0iXQ%3D%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/shake/",
                        "name": "Shake"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹100 for one"
                }
            },
            "order": {
                "deliveryTime": "25 min",
                "isServiceable": true,
                "hasOnlineOrdering": true,
                "actionInfo": {
                    "text": "Order Now",
                    "clickUrl": "/mumbai/kirti-mahal-legacy-parel/order"
                }
            },
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/mumbai/kirti-mahal-legacy-parel/order",
                "clickActionDeeplink": ""
            },
            "distance": "2.2 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"2193ad87-028b-4d1a-aee9-f3675127982b\",\"location_type\":\"delivery_cell\",\"location_id\":\"4316646509572521984\",\"page_type\":\"delivery\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"18953699\",\"element_type\":\"listing\",\"rank\":5}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [],
            "promoOffer": "",
            "checkBulkOffers": true,
            "bulkOffers": [
                {
                    "text": "50% OFF",
                    "color": {
                        "tint": "500",
                        "type": "blue"
                    }
                }
            ],
            "isDisabled": false,
            "bottomContainers": [
                {
                    "image": {
                        "url": "https://b.zmtcdn.com/data/o2_assets/4bf016f32f05d26242cea342f30d47a31595763089.png"
                    },
                    "text": "22925+ orders placed from here recently"
                },
                {
                    "image": {
                        "url": "https://b.zmtcdn.com/data/o2_assets/695598f38d29d0e5d3f8ffe57cfdb94c1613145422.png",
                        "aspect_ratio": 2.0625
                    },
                    "text": "Restaurant partner follows WHO protocol"
                }
            ]
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 18429575,
                "name": "Mani's Lunch Home",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/5/18429575/a6797ca27f51dbb44233b805153b029d_o2_featured_v2.jpg"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/5/18429575/a6797ca27f51dbb44233b805153b029d_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "4.2",
                    "rating_text": "4.2",
                    "rating_subtitle": "Very Good",
                    "rating_color": "5BA829",
                    "votes": "9,382",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "4.1",
                            "reviewCount": "511",
                            "reviewTextSmall": "511 Reviews",
                            "subtext": "511 Dining Reviews",
                            "color": "#1C1C1C",
                            "ratingV2": "4.1",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Reviews",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "700"
                            }
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "4.3",
                            "reviewCount": "8,871",
                            "reviewTextSmall": "8,871 Reviews",
                            "subtext": "8,871 Delivery Reviews",
                            "color": "#E23744",
                            "ratingV2": "4.3",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Reviews",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "700"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹200 for two"
                },
                "cfo": {
                    "text": "₹100 for one"
                },
                "locality": {
                    "name": "Chembur, Mumbai",
                    "address": "Shop 1 & 2, Ground Floor, Komal Villa, Co-Op Premises Society Ltd, Road 2, Chembur, Mumbai",
                    "localityUrl": "mumbai/chembur-restaurants"
                },
                "timing": {
                    "text": "",
                    "color": ""
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiODVcIl19Il0%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/south-indian/",
                        "name": "South Indian"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiOTBcIl19Il0%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/street-food/",
                        "name": "Street Food"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTAwXCJdfSJd",
                        "url": "https://www.zomato.com/mumbai/restaurants/desserts/",
                        "name": "Desserts"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹100 for one"
                }
            },
            "order": {
                "deliveryTime": "34 min",
                "isServiceable": true,
                "hasOnlineOrdering": true,
                "actionInfo": {
                    "text": "Order Now",
                    "clickUrl": "/mumbai/manis-lunch-home-chembur/order"
                }
            },
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/mumbai/manis-lunch-home-chembur/order",
                "clickActionDeeplink": ""
            },
            "distance": "6.8 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"2193ad87-028b-4d1a-aee9-f3675127982b\",\"location_type\":\"delivery_cell\",\"location_id\":\"4316646509572521984\",\"page_type\":\"delivery\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"18429575\",\"element_type\":\"listing\",\"rank\":6}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [],
            "promoOffer": "",
            "checkBulkOffers": true,
            "bulkOffers": [
                {
                    "text": "₹30 OFF",
                    "color": {
                        "tint": "500",
                        "type": "blue"
                    }
                }
            ],
            "isDisabled": false,
            "bottomContainers": [
                {
                    "image": {
                        "url": "https://b.zmtcdn.com/data/o2_assets/4bf016f32f05d26242cea342f30d47a31595763089.png"
                    },
                    "text": "9375+ orders placed from here recently"
                },
                {
                    "image": {
                        "url": "https://b.zmtcdn.com/data/o2_assets/0b07ef18234c6fdf9365ad1c274ae0631612687510.png",
                        "aspect_ratio": 2.66666666667
                    },
                    "text": "Follows all Max Safety measures to ensure your food is safe"
                }
            ]
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 45060,
                "name": "Subway",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/chains/4/35004/9c9c5614ae656da63c55327768e32850_o2_featured_v2.jpg"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/chains/4/35004/9c9c5614ae656da63c55327768e32850_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "3.2",
                    "rating_text": "3.2",
                    "rating_subtitle": "Average",
                    "rating_color": "CDD614",
                    "votes": "10.9K",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "2.5",
                            "reviewCount": "443",
                            "reviewTextSmall": "443 Reviews",
                            "subtext": "443 Dining Reviews",
                            "color": "#1C1C1C",
                            "ratingV2": "2.5",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Reviews",
                            "bgColorV2": {
                                "type": "orange",
                                "tint": "300"
                            }
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "3.8",
                            "reviewCount": "10.5K",
                            "reviewTextSmall": "10.5K Reviews",
                            "subtext": "10.5K Delivery Reviews",
                            "color": "#E23744",
                            "ratingV2": "3.8",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Reviews",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "600"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹400 for two"
                },
                "cfo": {
                    "text": "₹100 for one"
                },
                "locality": {
                    "name": "Matunga East, Mumbai",
                    "address": "5, Vora Bhavan, Near Dena Bank, Maheshwari Udyan, King Circle, Matunga East, Mumbai",
                    "localityUrl": "mumbai/matunga-east-restaurants"
                },
                "timing": {
                    "text": "",
                    "color": ""
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTQzXCJdfSJd",
                        "url": "https://www.zomato.com/mumbai/restaurants/health-food/",
                        "name": "Healthy Food"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNDBcIl19Il0%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/fast-food/",
                        "name": "Fast Food"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMzA0XCJdfSJd",
                        "url": "https://www.zomato.com/mumbai/restaurants/sandwich/",
                        "name": "Sandwich"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiOTk4XCJdfSJd",
                        "url": "https://www.zomato.com/mumbai/restaurants/salad/",
                        "name": "Salad"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTAyNFwiXX0iXQ%3D%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/wraps/",
                        "name": "Wraps"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjcwXCJdfSJd",
                        "url": "https://www.zomato.com/mumbai/restaurants/beverages/",
                        "name": "Beverages"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹100 for one"
                }
            },
            "order": {
                "deliveryTime": "20 min",
                "isServiceable": true,
                "hasOnlineOrdering": true,
                "actionInfo": {
                    "text": "Order Now",
                    "clickUrl": "/SubwayMatunga/order"
                }
            },
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/SubwayMatunga/order",
                "clickActionDeeplink": ""
            },
            "distance": "1 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"2193ad87-028b-4d1a-aee9-f3675127982b\",\"location_type\":\"delivery_cell\",\"location_id\":\"4316646509572521984\",\"page_type\":\"delivery\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"45060\",\"element_type\":\"listing\",\"rank\":7}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [],
            "promoOffer": "",
            "checkBulkOffers": true,
            "bulkOffers": [
                {
                    "text": "20% OFF",
                    "color": {
                        "tint": "500",
                        "type": "blue"
                    }
                }
            ],
            "isDisabled": false,
            "bottomContainers": [
                {
                    "image": {
                        "url": "https://b.zmtcdn.com/data/o2_assets/4bf016f32f05d26242cea342f30d47a31595763089.png"
                    },
                    "text": "7675+ orders placed from here recently"
                },
                {
                    "image": {
                        "url": "https://b.zmtcdn.com/data/o2_assets/695598f38d29d0e5d3f8ffe57cfdb94c1613145422.png",
                        "aspect_ratio": 2.0625
                    },
                    "text": "Restaurant partner follows WHO protocol"
                }
            ]
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 19907788,
                "name": "KFC",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/chains/7/37327/8065982bd1e5b32ea7730a382f7e1d93_o2_featured_v2.jpg"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/chains/7/37327/8065982bd1e5b32ea7730a382f7e1d93_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "3.2",
                    "rating_text": "3.2",
                    "rating_subtitle": "Average",
                    "rating_color": "CDD614",
                    "votes": "1,419",
                    "subtext": "REVIEW",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "2.6",
                            "reviewCount": "13",
                            "reviewTextSmall": "13 Reviews",
                            "subtext": "13 Dining Reviews",
                            "color": "#1C1C1C",
                            "ratingV2": "2.6",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Reviews",
                            "bgColorV2": {
                                "type": "yellow",
                                "tint": "600"
                            }
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "3.7",
                            "reviewCount": "1,406",
                            "reviewTextSmall": "1,406 Reviews",
                            "subtext": "1,406 Delivery Reviews",
                            "color": "#E23744",
                            "ratingV2": "3.7",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Reviews",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "600"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹400 for two"
                },
                "cfo": {
                    "text": "₹100 for one"
                },
                "locality": {
                    "name": "Hill Road, Bandra West, Mumbai",
                    "address": "Shop 5, Ground Floor, Near Times Square, CTS B/10 & B/11, Hill Road, Bandra West, Mumbai",
                    "localityUrl": "mumbai/hill-road-bandra-west-restaurants"
                },
                "timing": {
                    "text": "",
                    "color": ""
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTY4XCJdfSJd",
                        "url": "https://www.zomato.com/mumbai/restaurants/burger/",
                        "name": "Burger"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNDBcIl19Il0%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/fast-food/",
                        "name": "Fast Food"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjcwXCJdfSJd",
                        "url": "https://www.zomato.com/mumbai/restaurants/beverages/",
                        "name": "Beverages"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹100 for one"
                }
            },
            "order": {
                "deliveryTime": "59 min",
                "isServiceable": true,
                "hasOnlineOrdering": true,
                "actionInfo": {
                    "text": "Order Now",
                    "clickUrl": "/mumbai/kfc-1-hill-road-bandra-west/order"
                }
            },
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/mumbai/kfc-1-hill-road-bandra-west/order",
                "clickActionDeeplink": ""
            },
            "distance": "5.1 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"2193ad87-028b-4d1a-aee9-f3675127982b\",\"location_type\":\"delivery_cell\",\"location_id\":\"4316646509572521984\",\"page_type\":\"delivery\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"19907788\",\"element_type\":\"listing\",\"rank\":8}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [],
            "promoOffer": "",
            "checkBulkOffers": true,
            "bulkOffers": [],
            "isDisabled": false,
            "bottomContainers": [
                {
                    "image": {
                        "url": "https://b.zmtcdn.com/data/o2_assets/4bf016f32f05d26242cea342f30d47a31595763089.png"
                    },
                    "text": "5925+ orders placed from here recently"
                },
                {
                    "image": {
                        "url": "https://b.zmtcdn.com/data/o2_assets/0b07ef18234c6fdf9365ad1c274ae0631612687510.png",
                        "aspect_ratio": 2.66666666667
                    },
                    "text": "Follows all Max Safety measures to ensure your food is safe"
                }
            ]
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 35240,
                "name": "Natural Ice Cream",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/chains/0/35240/d7d11466e85c31bb241acac61c73eaa6_o2_featured_v2.jpg"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/chains/0/35240/d7d11466e85c31bb241acac61c73eaa6_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "4.4",
                    "rating_text": "4.4",
                    "rating_subtitle": "Very Good",
                    "rating_color": "5BA829",
                    "votes": "2,621",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "4.2",
                            "reviewCount": "416",
                            "reviewTextSmall": "416 Reviews",
                            "subtext": "416 Dining Reviews",
                            "color": "#1C1C1C",
                            "ratingV2": "4.2",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Reviews",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "700"
                            }
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "4.5",
                            "reviewCount": "2,205",
                            "reviewTextSmall": "2,205 Reviews",
                            "subtext": "2,205 Delivery Reviews",
                            "color": "#E23744",
                            "ratingV2": "4.5",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Reviews",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "700"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹300 for two"
                },
                "cfo": {
                    "text": "₹100 for one"
                },
                "locality": {
                    "name": "Matunga East, Mumbai",
                    "address": "2 & 3, 472, Mohan Niwas, King Circle, Matunga East, Mumbai",
                    "localityUrl": "mumbai/matunga-east-restaurants"
                },
                "timing": {
                    "text": "",
                    "color": ""
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjMzXCJdfSJd",
                        "url": "https://www.zomato.com/mumbai/restaurants/ice-cream/",
                        "name": "Ice Cream"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTA2NlwiXX0iXQ%3D%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/shake/",
                        "name": "Shake"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTAwXCJdfSJd",
                        "url": "https://www.zomato.com/mumbai/restaurants/desserts/",
                        "name": "Desserts"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹100 for one"
                }
            },
            "order": {
                "deliveryTime": "20 min",
                "isServiceable": true,
                "hasOnlineOrdering": true,
                "actionInfo": {
                    "text": "Order Now",
                    "clickUrl": "/mumbai/natural-ice-cream-matunga-east/order"
                }
            },
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/mumbai/natural-ice-cream-matunga-east/order",
                "clickActionDeeplink": ""
            },
            "distance": "954 m",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"2193ad87-028b-4d1a-aee9-f3675127982b\",\"location_type\":\"delivery_cell\",\"location_id\":\"4316646509572521984\",\"page_type\":\"delivery\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"35240\",\"element_type\":\"listing\",\"rank\":9}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [],
            "promoOffer": "",
            "checkBulkOffers": true,
            "bulkOffers": [
                {
                    "text": "30% OFF",
                    "color": {
                        "tint": "500",
                        "type": "blue"
                    }
                }
            ],
            "isDisabled": false,
            "bottomContainers": [
                {
                    "image": {
                        "url": "https://b.zmtcdn.com/data/o2_assets/4bf016f32f05d26242cea342f30d47a31595763089.png"
                    },
                    "text": "2350+ orders placed from here recently"
                },
                {
                    "image": {
                        "url": "https://b.zmtcdn.com/data/o2_assets/695598f38d29d0e5d3f8ffe57cfdb94c1613145422.png",
                        "aspect_ratio": 2.0625
                    },
                    "text": "Restaurant partner follows WHO protocol"
                }
            ]
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 18279512,
                "name": "Sbarro - New York Pizza",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/chains/4/43984/97293d96278f57d63c60822cbba7fe6c_o2_featured_v2.jpg"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/chains/4/43984/97293d96278f57d63c60822cbba7fe6c_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "3.7",
                    "rating_text": "3.7",
                    "rating_subtitle": "Good",
                    "rating_color": "9ACD32",
                    "votes": "7,537",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "3.5",
                            "reviewCount": "353",
                            "reviewTextSmall": "353 Reviews",
                            "subtext": "353 Dining Reviews",
                            "color": "#1C1C1C",
                            "ratingV2": "3.5",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Reviews",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "500"
                            }
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "3.8",
                            "reviewCount": "7,184",
                            "reviewTextSmall": "7,184 Reviews",
                            "subtext": "7,184 Delivery Reviews",
                            "color": "#E23744",
                            "ratingV2": "3.8",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Reviews",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "600"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹500 for two"
                },
                "cfo": {
                    "text": "₹100 for one"
                },
                "locality": {
                    "name": "Worli, Mumbai",
                    "address": "Shop 11-12, Ground Floor, Opposite Croma, Ramodiya Mansion, Dr. Annie Besant Road, Worli, Mumbai",
                    "localityUrl": "mumbai/worli-restaurants"
                },
                "timing": {
                    "text": "",
                    "color": ""
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiODJcIl19Il0%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/pizza/",
                        "name": "Pizza"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNDBcIl19Il0%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/fast-food/",
                        "name": "Fast Food"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTAwXCJdfSJd",
                        "url": "https://www.zomato.com/mumbai/restaurants/desserts/",
                        "name": "Desserts"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹100 for one"
                }
            },
            "order": {
                "deliveryTime": "38 min",
                "isServiceable": true,
                "hasOnlineOrdering": true,
                "actionInfo": {
                    "text": "Order Now",
                    "clickUrl": "/mumbai/sbarro-new-york-pizza-worli/order"
                }
            },
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/mumbai/sbarro-new-york-pizza-worli/order",
                "clickActionDeeplink": ""
            },
            "distance": "3.4 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"2193ad87-028b-4d1a-aee9-f3675127982b\",\"location_type\":\"delivery_cell\",\"location_id\":\"4316646509572521984\",\"page_type\":\"delivery\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"18279512\",\"element_type\":\"listing\",\"rank\":10}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [],
            "promoOffer": "",
            "checkBulkOffers": true,
            "bulkOffers": [
                {
                    "text": "60% OFF",
                    "color": {
                        "tint": "500",
                        "type": "blue"
                    }
                }
            ],
            "isDisabled": false,
            "bottomContainers": [
                {
                    "image": {
                        "url": "https://b.zmtcdn.com/data/o2_assets/4bf016f32f05d26242cea342f30d47a31595763089.png"
                    },
                    "text": "4325+ orders placed from here recently"
                },
                {
                    "image": {
                        "url": "https://b.zmtcdn.com/data/o2_assets/0b07ef18234c6fdf9365ad1c274ae0631612687510.png",
                        "aspect_ratio": 2.66666666667
                    },
                    "text": "Follows all Max Safety measures to ensure your food is safe"
                }
            ]
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 18995314,
                "name": "Theobroma",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/chains/7/34407/f02d83c8cbfad6a3ced14cc9cee41503_o2_featured_v2.jpg"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/chains/7/34407/f02d83c8cbfad6a3ced14cc9cee41503_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "4.0",
                    "rating_text": "4.0",
                    "rating_subtitle": "Very Good",
                    "rating_color": "5BA829",
                    "votes": "4,245",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "3.7",
                            "reviewCount": "170",
                            "reviewTextSmall": "170 Reviews",
                            "subtext": "170 Dining Reviews",
                            "color": "#1C1C1C",
                            "ratingV2": "3.7",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Reviews",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "600"
                            }
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "4.2",
                            "reviewCount": "4,075",
                            "reviewTextSmall": "4,075 Reviews",
                            "subtext": "4,075 Delivery Reviews",
                            "color": "#E23744",
                            "ratingV2": "4.2",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Reviews",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "700"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹400 for two"
                },
                "cfo": {
                    "text": "₹100 for one"
                },
                "locality": {
                    "name": "Matunga East, Mumbai",
                    "address": "Shop 6, Mohanlal Mansion, Dr Baba Saheb Ambedkar Road, Maheshwari Dhyan, Matunga East, Mumbai",
                    "localityUrl": "mumbai/matunga-east-restaurants"
                },
                "timing": {
                    "text": "",
                    "color": ""
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNVwiXX0iXQ%3D%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/bakery/",
                        "name": "Bakery"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNDBcIl19Il0%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/fast-food/",
                        "name": "Fast Food"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMjcwXCJdfSJd",
                        "url": "https://www.zomato.com/mumbai/restaurants/beverages/",
                        "name": "Beverages"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTAwXCJdfSJd",
                        "url": "https://www.zomato.com/mumbai/restaurants/desserts/",
                        "name": "Desserts"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹100 for one"
                }
            },
            "order": {
                "deliveryTime": "15 min",
                "isServiceable": true,
                "hasOnlineOrdering": true,
                "actionInfo": {
                    "text": "Order Now",
                    "clickUrl": "/mumbai/theobroma-matunga-east/order"
                }
            },
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/mumbai/theobroma-matunga-east/order",
                "clickActionDeeplink": ""
            },
            "distance": "1 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"2193ad87-028b-4d1a-aee9-f3675127982b\",\"location_type\":\"delivery_cell\",\"location_id\":\"4316646509572521984\",\"page_type\":\"delivery\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"18995314\",\"element_type\":\"listing\",\"rank\":11}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [],
            "promoOffer": "",
            "checkBulkOffers": true,
            "bulkOffers": [],
            "isDisabled": false,
            "bottomContainers": [
                {
                    "image": {
                        "url": "https://b.zmtcdn.com/data/o2_assets/4bf016f32f05d26242cea342f30d47a31595763089.png"
                    },
                    "text": "5175+ orders placed from here recently"
                },
                {
                    "image": {
                        "url": "https://b.zmtcdn.com/data/o2_assets/0b07ef18234c6fdf9365ad1c274ae0631612687510.png",
                        "aspect_ratio": 2.66666666667
                    },
                    "text": "Follows all Max Safety measures to ensure your food is safe"
                }
            ]
        },
        {
            "type": "restaurant",
            "info": {
                "resId": 17949712,
                "name": "Hangout Cakes & More",
                "image": {
                    "url": "https://b.zmtcdn.com/data/pictures/chains/6/37086/0d168593e5a5b4987d61a9f5b10d714f_o2_featured_v2.jpg"
                },
                "o2FeaturedImage": {
                    "url": "https://b.zmtcdn.com/data/pictures/chains/6/37086/0d168593e5a5b4987d61a9f5b10d714f_o2_featured_v2.jpg"
                },
                "rating": {
                    "has_fake_reviews": 0,
                    "aggregate_rating": "4.0",
                    "rating_text": "4.0",
                    "rating_subtitle": "Very Good",
                    "rating_color": "5BA829",
                    "votes": "3,523",
                    "subtext": "REVIEWS",
                    "is_new": false
                },
                "ratingNew": {
                    "newlyOpenedObj": null,
                    "suspiciousReviewObj": null,
                    "ratings": {
                        "DINING": {
                            "rating_type": "DINING",
                            "rating": "",
                            "reviewCount": "0",
                            "reviewTextSmall": "0 Reviews",
                            "subtext": "Does not offer Dining",
                            "color": "",
                            "ratingV2": "-",
                            "subtitle": "DINING",
                            "sideSubTitle": "Dining Reviews",
                            "bgColorV2": {
                                "type": "grey",
                                "tint": "500"
                            }
                        },
                        "DELIVERY": {
                            "rating_type": "DELIVERY",
                            "rating": "4.0",
                            "reviewCount": "3,523",
                            "reviewTextSmall": "3,523 Reviews",
                            "subtext": "3,523 Delivery Reviews",
                            "color": "#E23744",
                            "ratingV2": "4.0",
                            "subtitle": "DELIVERY",
                            "sideSubTitle": "Delivery Reviews",
                            "bgColorV2": {
                                "type": "green",
                                "tint": "600"
                            },
                            "newOnDelivery": false
                        }
                    }
                },
                "cft": {
                    "text": "₹400 for two"
                },
                "cfo": {
                    "text": "₹100 for one"
                },
                "locality": {
                    "name": "Matunga East, Mumbai",
                    "address": "Ground Floor, Kalyan Bhavan, Opposite Maheshwari Udyan Kings Cirle, Matunga East, Mumbai",
                    "localityUrl": "mumbai/matunga-east-restaurants"
                },
                "timing": {
                    "text": "",
                    "color": ""
                },
                "cuisine": [
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNVwiXX0iXQ%3D%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/bakery/",
                        "name": "Bakery"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiMTAwXCJdfSJd",
                        "url": "https://www.zomato.com/mumbai/restaurants/desserts/",
                        "name": "Desserts"
                    },
                    {
                        "deeplink": "zomato://search?deeplink_filters=WyJ7XCJjb250ZXh0XCI6XCJhbGxcIn0iLCJ7XCJjdWlzaW5lX2lkXCI6W1wiNDBcIl19Il0%3D",
                        "url": "https://www.zomato.com/mumbai/restaurants/fast-food/",
                        "name": "Fast Food"
                    }
                ],
                "should_ban_ugc": false,
                "costText": {
                    "text": "₹100 for one"
                }
            },
            "order": {
                "deliveryTime": "15 min",
                "isServiceable": true,
                "hasOnlineOrdering": true,
                "actionInfo": {
                    "text": "Order Now",
                    "clickUrl": "/mumbai/hangout-cakes-more-matunga-east/order"
                }
            },
            "gold": [],
            "takeaway": [],
            "cardAction": {
                "text": "",
                "clickUrl": "/mumbai/hangout-cakes-more-matunga-east/order",
                "clickActionDeeplink": ""
            },
            "distance": "1 km",
            "isPromoted": false,
            "promotedText": "",
            "trackingData": [
                {
                    "table_name": "zsearch_events_log",
                    "payload": "{\"search_id\":\"2193ad87-028b-4d1a-aee9-f3675127982b\",\"location_type\":\"delivery_cell\",\"location_id\":\"4316646509572521984\",\"page_type\":\"delivery\",\"app_type\":\"new_web_consumer\",\"section\":\"restaurants\",\"entity_type\":\"restaurant\",\"entity_id\":\"17949712\",\"element_type\":\"listing\",\"rank\":12}",
                    "event_names": {
                        "tap": "{\"action\":\"tap\"}",
                        "impression": "{\"action\":\"impression\"}"
                    }
                }
            ],
            "allCTA": [],
            "promoOffer": "",
            "checkBulkOffers": true,
            "bulkOffers": [
                {
                    "text": "Pro extra 10% OFF",
                    "color": {
                        "tint": "600",
                        "type": "pink"
                    }
                },
                {
                    "text": "60% OFF",
                    "color": {
                        "tint": "500",
                        "type": "blue"
                    }
                }
            ],
            "isDisabled": false,
            "bottomContainers": [
                {
                    "image": {
                        "url": "https://b.zmtcdn.com/data/o2_assets/4bf016f32f05d26242cea342f30d47a31595763089.png"
                    },
                    "text": "4225+ orders placed from here recently"
                },
                {
                    "image": {
                        "url": "https://b.zmtcdn.com/data/o2_assets/0b07ef18234c6fdf9365ad1c274ae0631612687510.png",
                        "aspect_ratio": 2.66666666667
                    },
                    "text": "Follows all Max Safety measures to ensure your food is safe"
                }
            ]
        }
    ]

import React from "react";

function Footer() {
  return (
    <div className="absolute-center">
      <a href="https://github.com/MrSagarRB"> Made By 💕 Sagar </a>
    </div>
  );
}

export default Footer;
